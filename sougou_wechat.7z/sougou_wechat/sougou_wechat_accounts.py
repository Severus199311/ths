#根据关键词获取搜狗微信公众号

import requests
from logger import logger
from bs4 import BeautifulSoup
import xlwt, xlrd
from xlutils.copy import copy
from sougou_config import *
import re, time, random, uuid

class SougouOfficialAccounts():

	def __init__(self):

		self.workbook_title = 'wechat_accounts.xls'
		self.sheet_name = 'Sheet1' #待录入种子所在的表名
		self.sheet_order = 0 #待录入种子所在的表序号
		self.columns_dict = {'account_name': 2, 'account_id': 3,'account_owner': 4, 'account_intro':5, 'latest_article_title':6} #key是字段，value是字段所在列的序号。写入的时候需要
		self.workbook_read = xlrd.open_workbook(self.workbook_title) #打开excel文件，用于读取数据
		self.sheet_data = self.workbook_read.sheet_by_name(self.sheet_name) #读取表数据
		self.keys_list = self.sheet_data.row_values(0) #获取列名，格式为list
		self.workbook_write = copy(self.workbook_read) #复制excel文件，用于写入
		self.processing_row = 0 #初始行序号为0
		self.if_successful_column_order = 1 #if_successful在第2列，所以是1
		self.if_successful_marker = 1

		self.base_url_article = 'https://weixin.sogou.com/weixin?query={}&s_from=input&type=2&page=1&ie=utf8'
		self.base_url_account = 'https://weixin.sogou.com/weixin?type=1&s_from=input&query={}'
		#self.base_url_seeds_name = 'http://flashcms.10jqka.com.cn/seed/seed/searchSeed/?platform=&disabled=&keywords={}&central=1&page=1&sourceid=&pageSize=20'
		self.base_url_seeds_url = 'http://flashcms.10jqka.com.cn/seed/seed/searchSeed/?platform=&disabled=&keywords={}&central=1&page=1&sourceid=&pageSize=20'
		self.current_keyword_article = 37
		self.current_keyword_account = 0
		
		#爬区帐号用固定headers_sougou， 爬取文章用随即搭配的cookie
		self.headers_sougou = {
			'Cookie': 'SUV=00C3E8BF7934FC1E6358F4A6D3ED9318; SNUID=05E72F631B1FF769ADC2BB4D1BF8EB76',
			'User-Agent': 'Mozilla/5.0 (Windows NT {}.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.212 Safari/537.36'.format(str(random.choice(range(1,10000))))
		}

		self.headers_seeds = {
			'Cookie': 'PHPSESSID=tft1f9dlha2uclqmm4oi42q9d4; Hm_lvt_8842296228f98310f233a1573b8fc447=1623813633; Hm_lpvt_8842296228f98310f233a1573b8fc447=1623813633; Hm_lvt_dbe230339e390fd27867f447ce3ac202=1623814270,1623814399,1623814423,1623814431; Hm_lpvt_dbe230339e390fd27867f447ce3ac202=1623814431; Hm_lvt_caf4708820e586710faf9bd4b3621aea=1623814539,1623814560,1623814675; Hm_lpvt_caf4708820e586710faf9bd4b3621aea=1623814675; UM_distinctid=17a133164641d6-024a69e62238a6-3c3b5809-1fa400-17a133164655e1; CNZZDATA1261534416=1511452341-1623815410-null%7C1623815410; CNZZDATA1260209010=614622258-1623815878-null%7C1623817720; _gscu_360798702=23821953w2qppq97; _gscbrs_360798702=1; Hm_lvt_5c3d520d131f79b2e027c95704f603d6=1623822980,1623823012; Hm_lpvt_5c3d520d131f79b2e027c95704f603d6=1623823012; _trs_uv=kpz2b8us_1_d8kx; CNZZDATA1259271766=779274467-1623824455-http%253A%252F%252Fflashcms.10jqka.com.cn%252F%7C1623824455; _gscbrs_1522955334=1; _gscu_1522955334=23827695f7435q97; CNZZDATA2255174=cnzz_eid%3D133752545-1623822834-http%253A%252F%252Fflashcms.10jqka.com.cn%252F%26ntime%3D1623822834; _gscu_566264591=23829331m2sgg297; _gscbrs_566264591=1; Hm_lvt_05f034db15111283852080b7441c35dc=1623823147,1623823232,1623831893; Hm_lpvt_05f034db15111283852080b7441c35dc=1623831893; Hm_lvt_ac134178e437e9dac7f70b5382674ca2=1623892349,1623892439; Hm_lpvt_ac134178e437e9dac7f70b5382674ca2=1623892439; _gscu_588215241=23895565oie5rf97; _gscbrs_588215241=1; _gscbrs_564480031=1; _gscu_564480031=238987303twqln97; CNZZDATA1279554173=1100921313-1623910152-null%7C1623910152; _gscu_594274046=23913029o1cjs597; _gscbrs_594274046=1; visitorIdUpdate=5; _wa_id.0=deda3131d69b8670.1623913029186.0.1623913829517.; _wa_id.59=ad91debb27a535e8.1623913029190.0.1623913829518.; Hm_lvt_3d463f371fd7cf73f06349062dedf800=1623913029,1623913282,1623913300,1623913830; Hm_lpvt_3d463f371fd7cf73f06349062dedf800=1623913830; Hm_lpvt_130440ab9b143126b84a1419c30fbadb=1623915009; Hm_lvt_130440ab9b143126b84a1419c30fbadb=1623915009; Hm_lpvt_9875513ba2dc935e2049a7990bb4fe2f=1623916971; Hm_lvt_9875513ba2dc935e2049a7990bb4fe2f=1623914433,1623915129,1623916962,1623916971; Hm_lpvt_aff7d9906dbc285a33c9d55ba6d560a7=1623916971; Hm_lvt_aff7d9906dbc285a33c9d55ba6d560a7=1623914433,1623915129,1623916962,1623916971; pgv_info=ssid=s3737294200; pgv_pvid=7217860436; ts_uid=850683000; CNZZDATA1261883897=1844401728-1623908005-http%253A%252F%252Fflashcms.10jqka.com.cn%252F%7C1623982156; _gscu_844674726=23985472e13nq813; _gscbrs_844674726=1; wdcid=6581ac2bb0f460d1; CNZZDATA1259641870=378475934-1623993161-http%253A%252F%252Fflashcms.10jqka.com.cn%252F%7C1623993161; CNZZDATA5957217=cnzz_eid%3D40436790-1623996217-http%253A%252F%252Fflashcms.10jqka.com.cn%252F%26ntime%3D1623996217; _gscu_2018095938=23996992pauggh13; _gscbrs_2018095938=1; CNZZDATA1256511679=192810680-1623993723-http%253A%252F%252Fflashcms.10jqka.com.cn%252F%7C1623999129; _gscu_1317058468=24001016miyq7j13; _gscbrs_1317058468=1; Hm_lpvt_299ef6f0c5c3e819dd2482733e71a534=1624003926; Hm_lvt_299ef6f0c5c3e819dd2482733e71a534=1624003926; CNZZDATA1000134872=1184647520-1624001610-http%253A%252F%252Fflashcms.10jqka.com.cn%252F%7C1624001610; _gscu_2110639996=24004707fkjsvy13; _gscbrs_2110639996=1; _ga=GA1.1.740850659.1624005453; sso_c=0; sfr=1; wdses=4af2652541351317; wdlast=1624254827; br-client=1a698f48-c7f6-47f7-8f3c-6ac04db2e5ba; br-session-75=43701eb2-0566-4c2f-a06b-c2960329d627|1624258410828|1624258745251|17; br-session-74=3df8cdf5-09c8-4026-a060-dc5328162091|1624277183910|1624277339989|6'
		}

	def build_sougou_headers(self):

		return {
			#'Cookie': 'SUV=' + str(uuid.uuid4()).replace('-', ''),
			#'Cookie': random.choice(sougou_cookies),
			#'Cookie': 'SUV=%s; SNUID=%s' % (str(uuid.uuid4()).replace('-', ''), str(uuid.uuid4()).replace('-', '')),
			#'Cookie': 'SUV=00C3E8BF7934FC1E6358F4A6D3ED9318; SNUID=AF4D84C9B1B55CD742E031F6B149C998',
			'Cookie': 'SUV=00777CA5654729E960B445ECDDA58105; SNUID=%s' % (str(uuid.uuid4()).replace('-', '')),
			'User-Agent': 'Mozilla/5.0 (Windows NT {}.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.212 Safari/537.36'.format(str(random.choice(range(1,10000))))
		}

	def fetch_account_dict(self):

		self.processing_row += 1
		value_list = self.sheet_data.row_values(self.processing_row)
		account_dict = dict(zip(self.keys_list, value_list))
		if not account_dict.get('if_successful'):
			return account_dict
		return None

	def write_into_excel(self, account_dict):

		sheet = self.workbook_write.get_sheet(self.sheet_order)
		sheet.write(self.processing_row, self.if_successful_column_order, self.if_successful_marker)
		if account_dict.get('account_id'):
			sheet.write(self.processing_row, self.columns_dict.get('account_id'), str(account_dict.get('account_id')))
		if account_dict.get('account_owner'):
			sheet.write(self.processing_row, self.columns_dict.get('account_owner'), str(account_dict.get('account_owner')))
		if account_dict.get('account_intro'):
			sheet.write(self.processing_row, self.columns_dict.get('account_intro'), str(account_dict.get('account_intro')))
		if account_dict.get('latest_article_title'):
			sheet.write(self.processing_row, self.columns_dict.get('latest_article_title'), str(account_dict.get('latest_article_title')))
		self.workbook_write.save(self.workbook_title)
		logger.info(account_dict)

	#获取搜狗文章页面
	def get_articles_page(self, keyword):

		url = self.base_url_article.format(keyword)

		try:
			response = requests.get(url, headers=self.build_sougou_headers())
			#response = requests.get(url, headers=self.headers_sougou)
		except Exception as e:
			logger.error(url + ' 搜狗文章请求失败，原因：' + e.args[0])
			return None
			
		if response.status_code == 200:
			return self.parse_articles_page(response.text)
		else:
			logger.error(url + ' 无效的响应码：' + str(response.status_code))
			return None

	def parse_articles_page(self, html):

		articles_list = []
		soup = BeautifulSoup(html, 'html.parser')
		article_elements_list = soup.select('#main > div.news-box > ul.news-list > li')
		for article_element in article_elements_list:
			article_dict = {}
			account_name = article_element.select('div.txt-box > div.s-p > a.account')[0].get_text()
			article_dict['account_name'] = account_name
			account_url = article_element.select('div.txt-box > div.s-p > a.account')[0].attrs['href']
			article_dict['account_url'] = 'https://weixin.sogou.com' + account_url
			article_title = article_element.select('div.txt-box > h3 > a')[0].get_text()
			article_dict['article_title'] = article_title
			article_url = article_element.select('div.txt-box > h3 > a')[0].attrs['href']
			article_dict['article_url'] = 'https://weixin.sogou.com' + article_url
			articles_list.append(article_dict)
		return articles_list

	#获取搜狗公众号页面
	def get_accounts_page(self, account_name):

		account_dict = {'account_name': account_name}
		url = self.base_url_account.format(account_name)
		
		try:
			response = requests.get(url, headers=self.build_sougou_headers())
			response.encoding = 'utf-8'
		except Exception as e:
			logger.error(url + ' 搜狗公众号请求失败，原因：' + e.args[0])
			return None

		if response.status_code == 200:
			try:
				return self.parse_accounts_page(response.text, account_dict)
			except Exception as e:
				logger.error(url + ' 搜狗公众号解析失败，原因：' + e.args[0])
		else: 
			logger.error(url + ' 无效的响应码：' + str(response.status_code))
			return None

	def parse_accounts_page(self, html, account_dict): #只能精确搜索

		soup = BeautifulSoup(html, 'html.parser')
		#logger.info(soup)
		for account_element in soup.select('.news-list2 > li'):

			if len(account_element.select('dl')) > 1: #有的公众号连最新文章一栏都没有，那些不要了
				if account_element.select('div > div.txt-box > p.tit > a > em')[0].get_text() == account_dict.get('account_name'): #名称一致

					#官方号认证
					try:
						verification_element = account_element.select('dl:nth-child(3) > dd > i.identify')[0]
						account_owner = verification_element.parent.get_text().strip('\n')
					except IndexError:
						account_owner = None

					#最近发文时间
					if account_owner:
						latest_article_element = account_element.select('dl:nth-child(4) > dd')[0]
					else:
						latest_article_element = account_element.select('dl:nth-child(3) > dd')[0]
					latest_article_time_element = latest_article_element.select('span > script')
					latest_article_time = re.match('.*?document.write\(timeConvert\(\'(.*?)\'\)\).*', str(latest_article_time_element)).group(1)

					#半月没发文的不要
					if int(time.time()) - int(latest_article_time) < 60 * 60 * 24 * 15:
						account_id_element = account_element.select('div > div.txt-box > p.info > label')[0]
						account_id = account_id_element.get_text()
						account_intro_element = account_element.select('dl:nth-child(2) > dd')[0]
						account_intro = account_intro_element.get_text()
						latest_article_title = latest_article_element.select('a')[0].get_text()

						account_dict['account_id'] = account_id
						account_dict['account_owner'] = account_owner
						account_dict['account_intro'] = account_intro
						account_dict['latest_article_title'] = latest_article_title

						return account_dict
						#if account_dict['account_owner']: #目前打算只要有认证的公众号了
						#	return account_dict

					return account_dict
		return account_dict

	#判断该公众号是否已经有种子录入
	def seed_exists(self, account_id):
		response = requests.get(self.base_url_seeds_url.format(account_id), headers=self.headers_seeds)
		if response.status_code == 200:
			seeds_list = response.json().get('result').get('list')
			if seeds_list:
				for seed in seeds_list:
					if seed.get('url') == account_id:
						return True
			return False

		logger.error('种子库请求失败，响应码：' + str(response.status_code))
		return True

	def run_1(self):

		while True:
			keyword = keywords_list_6[self.current_keyword_article]
			logger.info('当前序号： ' + str(self.current_keyword_article) + ' 当前关键词： ' + keyword)
			articles_list = self.get_articles_page(keyword)
			for article in articles_list:
				del article['account_url']
				del article['article_url']
				del article['article_title']
				logger.info(article)
			self.current_keyword_article += 1
			time.sleep(5)

	def run_2(self):

		while True:
			keyword = keywords_list_7[self.current_keyword_account]
			logger.info('当前序号： ' + str(self.current_keyword_account) + ' 当前关键词： ' + keyword)
			account_dict = self.get_accounts_page(keyword)
			if account_dict:
				logger.info(account_dict)
			self.current_keyword_account += 1
			#time.sleep(5)

	def run_3(self):

		page_sum = 10
		for page in range(9, page_sum + 1):
			#url = 'https://weixin.sogou.com/weixin?query={}&_sug_type_=&s_from=input&_sug_=n&type=1&page={}&ie=utf8'.format('+'.join(keywords_list_8), str(page))
			url = 'https://weixin.sogou.com/weixin?query={}&_sug_type_=&s_from=input&_sug_=n&type=2&page={}&ie=utf8'.format('+'.join(keywords_list_8), str(page))
			response = requests.get(url, headers=self.build_sougou_headers())
			articles_list = self.parse_articles_page(response.text)
			for article in articles_list:
				del article['account_url']
				del article['article_url']
				del article['article_title']
				logger.info(article)
			logger.info('第%s页' %(str(page)))

	#会被封ip
	def run_4(self):

		row_number = self.sheet_data.nrows - 1
		for row in range(row_number):
			for row in range(row_number):
				account_dict = self.fetch_account_dict()
				if account_dict:
					account_dict = self.get_accounts_page(account_dict.get('account_name'))
					if account_dict:
						self.write_into_excel(account_dict)

if __name__ == '__main__':

	sougou_official_account = SougouOfficialAccounts()
	sougou_official_account.run_4()