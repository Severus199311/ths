#针对需迁移到微信号，精确搜索，查询月发文数和最新文章日期
#轻易403，用不了

import requests
from logger import logger
from bs4 import BeautifulSoup
import xlwt, xlrd
from xlutils.copy import copy
import re, time

class SougouWechatBlacklisted():

	def __init__(self):
		
		self.workbook_title = 'wechat_accounts.xls'
		self.workbook_read = xlrd.open_workbook(self.workbook_title)
		self.sheet_name = 'Sheet1'
		self.sheet_data = self.workbook_read.sheet_by_name(self.sheet_name)
		self.keys_list = self.sheet_data.row_values(0)
		self.sheet_order = 0
		self.articles_month_column_order = 4
		self.articles_latest_column_order = 5
		self.processing_row = 0
		
		self.base_url_account = 'https://weixin.sogou.com/weixin?type=1&s_from=input&query='
		self.headers_sougou = {
			'Cookie': 'ABTEST=0|1662615263|v1; IPLOC=CN3301; SUID=1EFC3479AF21B00A0000000063197EE2; weixinIndexVisited=1; SUV=008724A47934FC1E63197EE577BAC797; JSESSIONID=aaaAnTOfztYP7c6h2zWky; PHPSESSID=mp54rbbucr97dqcr739jt5id86; SNUID=BF5E95D8A2A74987C17B7695A2974DB0; ariaDefaultTheme=undefined',
			'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36'
		}

	def fetch_wechat_account(self):

		self.processing_row += 1
		value_list = self.sheet_data.row_values(self.processing_row)
		account_dict = dict(zip(self.keys_list, value_list))
		if not account_dict.get('if_done'):
			return account_dict
		else:
			return None

	#获取搜狗公众号页面
	def get_accounts_page(self, account_dict):
		
		url = self.base_url_account + account_dict.get('account_name')
		try:
			response = requests.get(url, headers=self.headers_sougou)
		except Exception as e:
			logger.error(url + ' 搜狗公众号请求失败，原因：' + e.args[0])
			return None

		if response.status_code == 200:
			try:
				return self.parse_accounts_page(response.text, account_dict)
			except Exception as e:
				logger.error(url + ' 搜狗公众号解析失败，原因：' + e.args[0])
		else: 
			logger.error(url + ' 无效的响应码：' + str(response.status_code))
			return None

	def parse_accounts_page(self, html, account_dict):

		soup = BeautifulSoup(html, 'html.parser')
		account_elements_list = soup.select('.news-list2 > li')
		for account_element in account_elements_list:
			if account_element.select('div > div.txt-box > p.info > label')[0].get_text() == account_dict.get('account_id'): #微信id一致
				articles_month_text = account_element.select('div > div.txt-box > p.info')[0].get_text()
				logger.info("aaaaaaa:   " + articles_month_text)
				last_dl_text = account_element.select('dl')[-1].get_text()
				logger.info("bbbbbbb:   " + last_dl_text)
				break
		return None

	def run(self):

		row_number = self.sheet_data.nrows - 1
		for row in range(row_number):
			account_dict = self.fetch_wechat_account()
			self.get_accounts_page(account_dict)

if __name__ == '__main__':

	sougou_wechat_blacklisted = SougouWechatBlacklisted()
	sougou_wechat_blacklisted.run()