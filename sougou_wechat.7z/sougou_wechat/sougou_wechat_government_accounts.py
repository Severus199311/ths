#根据关键词获取搜狗微信公众号,专门获取政府官方公众号的

import requests
from logger import logger
from bs4 import BeautifulSoup
import xlwt, xlrd
from xlutils.copy import copy
from sougou_config import *
import re, time, random

class SougouWechatGovernmentAccounts():

	def __init__(self):
		self.workbook_title_a = 'wechat_accounts.xls'
		self.sheet_name = 'Sheet1' #待录入种子所在的表名
		self.sheet_order = 0 #待录入种子所在的表序号
		self.account_id_column_order = 2 #公众号id所在的列序号
		self.columns_dict = {'account_name':2, 'account_id':3, 'account_owner':9, 'account_intro':10, 'latest_article_title':11, 'keywords':12} #key是字段，value是字段所在列的序号。写入的时候需要
		self.base_url_account = 'https://weixin.sogou.com/weixin?type=1&s_from=input&query='
		
		#根据后台已有种子查重用的
		self.base_url_seeds_url = 'http://flashcms.10jqka.com.cn/seed/seed/searchSeed/?platform=&disabled=&keywords={}&central=1&page=1&sourceid=&pageSize=20'
		self.headers_seeds = {
			'Cookie': 'PHPSESSID=mspeo6b4g2c455fpvpbc1vgu96'
		}
		
		#爬区帐号用固定headers_sougou，爬文章则可随意拼凑
		self.headers_sougou = {
			'Cookie': random.choice(sougou_cookies),
			'User-Agent': 'Mozilla/5.0 (Windows NT {}.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.212 Safari/537.36'.format(str(random.choice(range(1,10000))))
		}
		
	def write_into_excel(self, account_dict):
		for each in unwanted_words_list_2:
			if each in account_dict.get('account_name'):
				return None

		workbook_read = xlrd.open_workbook(self.workbook_title_a) #打开excel文件，用于读取数据
		sheet_data = workbook_read.sheet_by_name(self.sheet_name) #读取表数据

		if not account_dict.get('account_id') in sheet_data.col_values(self.account_id_column_order): #如果表格里还没有这个公众号的id
			workbook_write = copy(workbook_read) #复制excel文件，用于写入
			row_number = sheet_data.nrows
			sheet_write = workbook_write.get_sheet(self.sheet_order) #用于写入的表格

			for key, value in self.columns_dict.items():
				sheet_write.write(row_number, value, account_dict.get(key))
			workbook_write.save(self.workbook_title_a)
			logger.info('……………………………………………………获取到公众号——' + account_dict.get('account_name'))

	#获取搜狗公众号页面
	def get_accounts_page(self, keyword_a, keyword_b):
		#url = self.base_url_account + keyword_a
		url = self.base_url_account + keyword_a + '+' +keyword_b
		try:
			response = requests.get(url, headers=self.headers_sougou)
		except Exception as e:
			logger.error(url + ' **********搜狗公众号请求失败，原因：' + e.args[0])
			return None

		if response.status_code == 200:
			try:
				#logger.info(response.text)
				return self.parse_accounts_page(response.text, keyword_a, keyword_b)
			except Exception as e:
				logger.error(url + ' **********搜狗公众号解析失败，原因：' + e.args[0]) #如果一个公众号有认证，但长时间未发文，也会报这个错
		else: 
			logger.error(url + ' **********无效的响应码：' + str(response.status_code))
			return None

	def parse_accounts_page(self, html, keyword_a, keyword_b):
		soup = BeautifulSoup(html, 'html.parser')
		accounts_list = []

		if soup.select('#noresult_part1_container'):
			logger.info('该页没有数据：' + keyword_a + '——' + keyword_b)
			return None		
		if not soup.select('.news-list2 > li'):
			logger.error('**********可能被拦截了：' + keyword_a + '——' + keyword_b)
			return None

		for account_element in soup.select('.news-list2 > li'):

			if len(account_element.select('dl')) > 1: #有的公众号连最新文章一栏都没有，那些不要了

					try:
						verification_element = account_element.select('dl:nth-child(3) > dd > i.identify')[0]
						account_owner = verification_element.parent.get_text().strip('\n')
					except IndexError:
						account_owner = None

					if account_owner: #没有用户认证的不要
						latest_article_element = account_element.select('dl:nth-child(4) > dd')[0]
						latest_article_time_element = latest_article_element.select('span > script')
						latest_article_time = re.match('.*?document.write\(timeConvert\(\'(.*?)\'\)\).*', str(latest_article_time_element)).group(1)

						if int(time.time()) - int(latest_article_time) < 60 * 60 * 24 * 30: #超过30天没发文字的也不要

							account_id = account_element.select('div > div.txt-box > p.info > label')[0].get_text()
							if not self.seed_exists(account_id):

								account_name = account_element.select('div > div.txt-box > p.tit > a')[0].get_text()
								account_intro = account_element.select('dl:nth-child(2) > dd')[0].get_text()
								latest_article_title = latest_article_element.select('a')[0].get_text()

								account_dict = {}
								account_dict['keywords'] = keyword_a + '-' + keyword_b
								account_dict['account_name'] = account_name
								account_dict['account_id'] = account_id
								account_dict['account_owner'] = account_owner
								account_dict['account_intro'] = account_intro
								account_dict['latest_article_title'] = latest_article_title

								accounts_list.append(account_dict)
		return accounts_list

	#判断该公众号是否已经有种子录入
	def seed_exists(self, account_id):
		response = requests.get(self.base_url_seeds_url.format(account_id), headers=self.headers_seeds)
		if response.status_code == 200:
			seeds_list = response.json().get('result').get('list')
			if seeds_list:
				for seed in seeds_list:
					if seed.get('url') == account_id:
						return True
			return False

		logger.error('种子库请求失败，响应码：' + str(response.status_code))
		return True

	

	def run(self):

		for a in governments_list_2[0:]:
			for b in keywords_list_4:
				accounts_list = self.get_accounts_page(a, b)
				
				if accounts_list:
					for account_dict in accounts_list:
						self.write_into_excel(account_dict)
		"""
		for a in keywords_list[0:]:
			accounts_list = self.get_accounts_page(a, '')
			if accounts_list:
				for account_dict in accounts_list:
					self.write_into_excel(account_dict)
		"""

if __name__ == '__main__':
	sougou_wechat_government_account = SougouWechatGovernmentAccounts()
	sougou_wechat_government_account.run()

