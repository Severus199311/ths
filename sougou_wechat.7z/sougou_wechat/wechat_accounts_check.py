#根据关键词获取搜狗微信公众号

import requests
from logger import logger
from bs4 import BeautifulSoup
import xlwt, xlrd
from xlutils.copy import copy
from sougou_config import *
import re, time, random,sys

class SougouOfficialAccounts():

	def __init__(self):

		self.workbook_title = 'wechat_accounts_to_be_checked.xls'
		self.sheet_name = 'Sheet1' #待检测公众号所在的表名
		self.sheet_order = 0 #待检测公众号所在的表序号
		self.workbook_read = xlrd.open_workbook(self.workbook_title) #打开excel文件，用于读取数据
		self.sheet_data = self.workbook_read.sheet_by_name(self.sheet_name) #读取表数据
		self.keys_list = self.sheet_data.row_values(0) #获取列名，格式为list
		self.workbook_write = copy(self.workbook_read) #复制excel文件，用于写入

		self.processing_row = 0 #初始行序号为0
		self.successful_marker = 1 #成功，则标记为1
		self.if_successful_column = 1
		self.id_by_name_column = 5
		self.if_id_consistent_column = 6
		self.name_by_id_column = 7
		self.if_name_consistent_column = 8

		self.check_by = 'name' #(只能是'id'或者'name')

		self.base_url_account = 'https://weixin.sogou.com/weixin?type=1&s_from=input&query='
		
		#爬区帐号用固定headers_sougou， 爬取文章用随即搭配的cookie
		self.headers_sougou = {
			'Cookie': 'ABTEST=4|1642063803|v1; IPLOC=CN3301; SUID=1EFC34793F18960A0000000061DFE7BC; SUID=1EFC3479AF21B00A0000000061DFE7BC; weixinIndexVisited=1; SUV=00F548DD7934FC1E61DFE7BEA7EBA639; JSESSIONID=aaaIxUDSDZjS95Ky-5c5x; PHPSESSID=op3oescdj0f1jniuaofnh44ct5; SNUID=CA29E1ACD5D0014E403BE4D1D5E77CE9; seccodeRight=success; successCount=3|Sat, 15 Jan 2022 08:19:16 GMT; ariaDefaultTheme=undefined',
			'User-Agent': 'Mozilla/5.0 (Windows NT {}.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.212 Safari/537.36'.format(str(random.choice(range(1,10000))))
		}

	def build_sougou_headers(self):

		return {
			'Cookie': random.choice(sougou_cookies),
			'User-Agent': 'Mozilla/5.0 (Windows NT {}.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.212 Safari/537.36'.format(str(random.choice(range(1,10000))))
		}

	def write_into_excel(self, account_dict):

		sheet = self.workbook_write.get_sheet(self.sheet_order)

		if account_dict.get('id_by_name') and account_dict.get('id_by_name') != '无效页面':
			sheet.write(self.processing_row, self.id_by_name_column, account_dict.get('id_by_name'))
		if account_dict.get('if_id_consistent'):
			sheet.write(self.processing_row, self.if_id_consistent_column, account_dict.get('if_id_consistent'))
		if account_dict.get('name_by_id') and account_dict.get('name_by_id') != '无效页面':
			sheet.write(self.processing_row, self.name_by_id_column, account_dict.get('name_by_id'))
		if account_dict.get('if_name_consistent'):
			sheet.write(self.processing_row, self.if_name_consistent_column, account_dict.get('if_name_consistent'))

		sheet.write(self.processing_row, self.if_successful_column, self.successful_marker)
		self.workbook_write.save(self.workbook_title)

		if self.check_by == 'id':
			logger.info(str(self.processing_row)+ ' ' + account_dict.get('name_by_id') + ' ' + str(account_dict.get('if_name_consistent')))
		if self.check_by == 'name':
			logger.info(str(self.processing_row)+ ' ' + account_dict.get('id_by_name') + ' ' + str(account_dict.get('if_id_consistent')))

	#从excel表格中获取待检测公众号信息
	def fetch_account_undone(self):

		self.processing_row += 1
		value_list = self.sheet_data.row_values(self.processing_row)
		account_dict = dict(zip(self.keys_list, value_list))
		if not account_dict.get('if_successful'):
			if self.check_by == 'id':
				if not account_dict.get('name_by_id'):
					return account_dict
			elif self.check_by == 'name':
				if not account_dict.get('id_by_name'):
					return account_dict
			else:
				logger.error('check_by 只能是 id 或者 name')
				sys.exit()
		return None


	#获取搜狗公众号页面
	def get_accounts_page(self, account_dict):

		if self.check_by == 'id':
			url = self.base_url_account + account_dict.get('account_id')
		elif self.check_by == 'name':
			url = self.base_url_account + account_dict.get('account_name')
		
		try:
			response = requests.get(url, headers=self.headers_sougou)
		except Exception as e:
			logger.error(url + ' 搜狗公众号请求失败，原因：' + e.args[0])
			return None

		if response.status_code == 200:
			try:
				return self.parse_accounts_page(response.text, account_dict)
			except Exception as e:
				logger.error(url + ' 搜狗公众号解析失败，原因：' + e.args[0])
		else: 
			logger.error(url + ' 无效的响应码：' + str(response.status_code))
			return None

	def parse_accounts_page(self, html, account_dict):

		soup = BeautifulSoup(html, 'html.parser')

		if 'document.cookie' in soup.get_text():
			if self.check_by == 'id':
				account_dict['name_by_id'] = '无效页面' 
			elif self.check_by == 'name':
				account_dict['id_by_name'] = '无效页面'	

		elif '暂无与' in soup.get_text() and '相关的官方认证订阅号'	in soup.get_text():
			if self.check_by == 'id':
				account_dict['name_by_id'] = '无' #搜不到任何公众号
			elif self.check_by == 'name':
				account_dict['id_by_name'] = '无'

		else:

			account_element_list = soup.select('.news-list2 > li')
			for account_element in account_element_list:

				if self.check_by == 'id':
					if account_element.select('div > div.txt-box > p.info > label')[0].get_text() == account_dict.get('account_id'):
						account_dict['name_by_id'] = account_element.select('div.gzh-box2 > div.txt-box > p.tit > a')[0].get_text()
						if account_dict.get('name_by_id') == account_dict.get('account_name'):
							account_dict['if_name_consistent'] = 1
						break
					account_dict['name_by_id'] = '错' #能搜到公众号，但无对应

				if self.check_by == 'name':
					if account_element.select('div > div.txt-box > p.tit > a')[0].get_text() == account_dict.get('account_name'):
						account_dict['id_by_name'] = account_element.select('div.gzh-box2 > div.txt-box > p.info > label')[0].get_text()
						if account_dict.get('id_by_name') == account_dict.get('account_id'):
							account_dict['if_id_consistent'] = 1
						break
					account_dict['id_by_name'] = '错'

		return account_dict

	def run(self):

		#"""
		row_number = self.sheet_data.nrows - 1
		for row in range(row_number):
			account_dict = self.fetch_account_undone()
			if account_dict:
				account_dict = self.get_accounts_page(account_dict)
				self.write_into_excel(account_dict)
		"""
		account_dict = {'account_id': 'KUKA_HOME'}
		account_dict = self.get_accounts_page(account_dict)
		print(account_dict)
		"""



if __name__ == '__main__':
	sougou_official_account = SougouOfficialAccounts()
	sougou_official_account.run()