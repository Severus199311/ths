import requests, xlwt, time, re
from xlutils.copy import copy
from logger2 import logger
from lxml import etree
from bs4 import BeautifulSoup

class YINSHINEWS():

	def __init__(self):

		self.start_date = time.strftime('%Y-%m-%d')
		self.end_date = time.strftime('%Y-%m-%d')
		self.page = 0
		self.next_page = True
		self.source = '%D2%F8%CA%C1%B2%C6%BE%AD' #'中文“银柿财经”不行'
		#资讯
		self.base_url = 'http://flashcms.10jqka.com.cn/input/formalnews/index/?title=&seq=&enter=&updater=&source={}&author=&hyname=&hyid=&conceptid=&newconceptid=&stockcode=&sclassname=&classid=&classname=&relate=0&remark=1&weight=&starttime={}&endtime={}&page={}'
		#同顺号
		#self.base_url = 'http://flashcms.10jqka.com.cn/entry/ContentServerAudit/index/?title=&author=%E6%B3%A1%E8%B4%A2%E7%BB%8F&status=&num=10&pid=&type=1&starttime={}%2000%3A00&refresh=0&endtime={}%2023%3A59&contentType=0&page={}'
		self.headers = {
			'Accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
			'Accept-Encoding':'gzip, deflate',
			'Accept-Language':'zh-CN,zh;q=0.9',
			'Connection':'keep-alive',
			'Cookie':'PHPSESSID=sefac4j659d3io64cm6i2mk5g4',
			'Host':'flashcms.10jqka.com.cn',
			'Upgrade-Insecure-Requests':'1',
			'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36'
		}
		self.article_dicts_list = []
		self.article_titles_list = []

	def get_yinshi_news(self, url):

		response = requests.get(url, headers=self.headers)
		response.encoding = 'gbk'

		return response.text


	def parse_yinshi_news(self, response_text):

		soup = BeautifulSoup(response_text, 'lxml')
		article_trs = soup.select('#newsTable tr')
		
		del article_trs[0]
		for article_tr in article_trs:
			article_dict = {}
			article_dict['url'] = article_tr.select('.oldUrl')[0].attrs.get('value')
			article_dict['title'] = article_tr.select('.c1')[0].get_text().replace('\n', '').strip(' ').replace('复制','').replace('，', ' ')
			article_dict['time'] = article_tr.select('.c9')[0].get_text().replace(' ', '')
			self.article_dicts_list.append(article_dict)
			self.article_titles_list.append(article_dict.get('title'))
		page_text = soup.select('.pages')[0].get_text()
		if not '下一页' in page_text:
			self.next_page = False


	def get_all_articles(self):

		while self.next_page:
			self.page += 1
			url = self.base_url.format(self.source, self.start_date, self.end_date, str(self.page))
			response_text = self.get_yinshi_news(url)
			self.parse_yinshi_news(response_text)

	def get_rss_articles(self):

		item_dicts_list = []
		url = 'https://www.yinsfinance.com/rss/feed_mrjj.xml'
		response = requests.get(url)
		response.encoding = 'UTF-8'
		items_list = re.findall('<item>(.*?)/item>', response.text, re.S)
		for item in items_list:
			formatted_time = re.match('.*?<pubDate><!\[CDATA\[ (.*?)\]', item, re.S).group(1).strip(' ')
			timestamp = self.make_time(formatted_time, '%Y/%m/%d %H:%M:%S')
			if 60*60*1 < int(time.time())-int(timestamp) < 60*60*10:
				title = re.match('.*?<title><!\[CDATA\[ (.*?)\]', item, re.S).group(1).strip(' ').replace('，', ' ')
				if not title in self.article_titles_list:
					article_url = re.match('.*?<link><!\[CDATA\[ (.*?)\]', item, re.S).group(1).strip(' ')
					self.missed_article_alert(title, article_url, formatted_time)

	def missed_article_alert(self, title, article_url, formatted_time):

		logger.info('标题： %s\n链接： %s\n时间： %s' %(title, article_url, formatted_time))

	def make_time(self, formatted_time, format):

		struct_time = time.strptime(formatted_time, format)
		timestamp = time.mktime(struct_time)
		return timestamp

	def run(self):

		while True:
			self.get_all_articles()
			self.get_rss_articles()
			logger.info('本次对比结束')
			time.sleep(60*60*1)

if __name__ == '__main__':

	yinshi_news = YINSHINEWS()
	yinshi_news.run()